<?php

try {
    $connection = new PDO
            (
            "mysql:host=localhost;dbname=chayopat_somedb",
            "chayopat",
            "WByq\$fc2!g!"
    );
} catch (Exception $e) {
    die("ERROR: Couldn't connect. {$e->getMessage()}");
}

?>